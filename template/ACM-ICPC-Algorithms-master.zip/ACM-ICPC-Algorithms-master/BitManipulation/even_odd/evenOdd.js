const x = 12;

if (x & 1)
  console.log(x + " is an odd number");
else
  console.log(x + " is an even number");
