x = int(input("Enter an integer: "))

if x & 1:
    print("%d is an odd number" % x)
else:
    print("%d is an even number" % x)
