Problem:
Given N jobs where every job is represented by following three elements of it.

    Start Time
    Finish Time
    Profit or Value Associated

Find the maximum profit subset of jobs such that no two jobs in the subset overlap.