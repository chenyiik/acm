
public class Driver {
	public static void main(String[] args) {
		SinglyLinkedList list = new SinglyLinkedList();
		list.add("Test");
		list.add("Test 2");
		list.add(25);
		list.add(27);
		System.out.println(list);
	}
}
