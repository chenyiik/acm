n = "12345"

digit_sum = sum(map(int, list(n)))
print(digit_sum)
