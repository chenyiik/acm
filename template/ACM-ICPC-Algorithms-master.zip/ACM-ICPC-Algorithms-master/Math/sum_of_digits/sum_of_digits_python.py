number = "123456" 
sum = 0        

for loop_variable in number:
  sum += int(loop_variable)
  
print(sum)
