git add .
git commit -m "add some changes"
git push
