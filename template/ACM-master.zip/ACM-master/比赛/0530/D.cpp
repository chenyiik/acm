#include  <cstdio>
using namespace std;
int main()
{
    int a[100000000];
}
