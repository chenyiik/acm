#include <cstdio>
#include <string>
#include <iostream>
using namespace std;
string a;
int ca = 1;
int main()
{
    while (cin >> a)
    {
        if (a == "I")
        {
            printf("Case %d: 1\n", ca++);
        }
        if (a == "II")
        {
            printf("Case %d: 2\n", ca++);
        }
        if (a == "III")
        {
            printf("Case %d: 3\n", ca++);
        }
        if (a == "IV")
        {
            printf("Case %d: 4\n", ca++);
        }
        if (a == "V")
        {
            printf("Case %d: 5\n", ca++);
        }
        if (a == "VI")
        {
            printf("Case %d: 6\n", ca++);
        }
        if (a == "VII")
        {
            printf("Case %d: 7\n", ca++);
        }
        if (a == "VIII")
        {
            printf("Case %d: 8\n", ca++);
        }
        if (a == "IX")
        {
            printf("Case %d: 9\n", ca++);
        }
        if (a == "X")
        {
            printf("Case %d: 10\n", ca++);
        }
        if (a == "XI")
        {
            printf("Case %d: 11\n", ca++);
        }
        if (a == "XII")
        {
            printf("Case %d: 12\n", ca++);
        }
    }
}
